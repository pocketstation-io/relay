package server

import (
	"github.com/pocketstation-io/relay/internal/auth"
	"github.com/pocketstation-io/relay/internal/signaling"
)

// handleKeyExchange forwards an SFrame KEY_EXCHANGE message from the source to
// all subscriber sessions in the room (RELAY-014). The relay forwards SFrameKey
// verbatim without reading the key material, preserving the SFrame guarantee
// that the relay never holds plaintext audio.
//
// Invariant: only the source role may send KEY_EXCHANGE.
func (s *session) handleKeyExchange(msg signaling.ClientMessage) {
	if s.role != auth.RoleSource {
		s.sendError(signaling.ErrCodeRoleMismatch, "KEY_EXCHANGE requires a source token")
		return
	}
	if s.room == nil {
		s.sendError(signaling.ErrCodeNotJoined, "join a session before sending KEY_EXCHANGE")
		return
	}

	forward := signaling.ServerMessage{
		Type:      signaling.TypeKeyExchange,
		SFrameKey: msg.SFrameKey,
	}

	s.srv.mu.RLock()
	sessions := make([]*session, 0, len(s.srv.sessions))
	for _, sess := range s.srv.sessions {
		sessions = append(sessions, sess)
	}
	s.srv.mu.RUnlock()

	for _, sess := range sessions {
		if sess.id == s.id || sess.room == nil || sess.room.ID != s.room.ID {
			continue
		}
		if sess.role == auth.RoleSubscriber || sess.role == auth.RoleListener {
			_ = sess.send(forward)
		}
	}

	s.srv.Metrics.KeyExchangeTotal.Add(1)

	if msg.SFrameKey != "" {
		s.room.SetKey(msg.SFrameKey)
	}
}
